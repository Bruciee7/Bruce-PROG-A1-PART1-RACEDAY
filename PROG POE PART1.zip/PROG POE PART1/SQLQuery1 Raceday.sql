
-- RaceDay Database Schema
-- Part 1 - Section C
-- Programming 2B (PROG6212)



-- Create Database

USE master;
GO

-- Drop database if it exists (for clean installation)
IF EXISTS (SELECT name FROM sys.databases WHERE name = N'RaceDayDB')
BEGIN
    ALTER DATABASE RaceDayDB SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE RaceDayDB;
END
GO

CREATE DATABASE RaceDayDB;
GO

USE RaceDayDB;
GO


-- Create Tables

-- 1. USER Table
-- Stores all users (both Organisers and Participants)

CREATE TABLE [User] (
    UserId INT IDENTITY(1,1) PRIMARY KEY,
    Email VARCHAR(255) NOT NULL UNIQUE,
    PasswordHash VARCHAR(500) NOT NULL,
    FirstName VARCHAR(100) NOT NULL,
    LastName VARCHAR(100) NOT NULL,
    [Role] VARCHAR(20) NOT NULL CHECK ([Role] IN ('Organiser', 'Participant')),
    ProfilePictureUrl VARCHAR(500) NULL,
    CreatedAt DATETIME DEFAULT GETDATE()
);
GO


-- 2. EVENT Table
-- Stores all events created by Organisers

CREATE TABLE [Event] (
    EventId INT IDENTITY(1,1) PRIMARY KEY,
    OrganiserId INT NOT NULL,
    [Name] VARCHAR(200) NOT NULL,
    [Description] VARCHAR(1000) NULL,
    [Date] DATETIME NOT NULL,
    [Location] VARCHAR(200) NOT NULL,
    Distance VARCHAR(50) NOT NULL, -- e.g., '10km', '21km', '42km'
    EventType VARCHAR(20) NOT NULL CHECK (EventType IN ('Run', 'Walk', 'Cycle')),
    BannerImageUrl VARCHAR(500) NULL,
    CreatedAt DATETIME DEFAULT GETDATE(),
    UpdatedAt DATETIME NULL,
    CONSTRAINT FK_Event_User FOREIGN KEY (OrganiserId) REFERENCES [User](UserId) ON DELETE CASCADE
);
GO


-- 3. CATEGORY Table
-- Stores categories for each event (age groups or distance categories)

CREATE TABLE [Category] (
    CategoryId INT IDENTITY(1,1) PRIMARY KEY,
    EventId INT NOT NULL,
    [Name] VARCHAR(100) NOT NULL, -- e.g., 'Under 20', 'Senior', '10km', '21km'
    [Description] VARCHAR(500) NULL,
    CONSTRAINT FK_Category_Event FOREIGN KEY (EventId) REFERENCES [Event](EventId) ON DELETE CASCADE
);
GO


-- 4. ENROLMENT Table
-- Tracks participants enrolled in events with selected categories

CREATE TABLE [Enrolment] (
    EnrolmentId INT IDENTITY(1,1) PRIMARY KEY,
    ParticipantId INT NOT NULL,
    EventId INT NOT NULL,
    CategoryId INT NOT NULL,
    [Status] VARCHAR(20) NOT NULL DEFAULT 'Pending' CHECK ([Status] IN ('Pending', 'Confirmed', 'Cancelled')),
    EnrolmentDate DATETIME DEFAULT GETDATE(),
    CONSTRAINT FK_Enrolment_User FOREIGN KEY (ParticipantId) REFERENCES [User](UserId) ON DELETE CASCADE,
    CONSTRAINT FK_Enrolment_Event FOREIGN KEY (EventId) REFERENCES [Event](EventId) ON DELETE CASCADE,
    CONSTRAINT FK_Enrolment_Category FOREIGN KEY (CategoryId) REFERENCES [Category](CategoryId),
    -- Prevent duplicate enrolments for same participant in same event
    CONSTRAINT UQ_Enrolment_ParticipantEvent UNIQUE (ParticipantId, EventId)
);
GO


-- 5. RESULT Table
-- Stores finish times and positions for completed enrolments

CREATE TABLE [Result] (
    ResultId INT IDENTITY(1,1) PRIMARY KEY,
    EnrolmentId INT NOT NULL UNIQUE, -- One-to-one relationship with Enrolment
    FinishTime VARCHAR(20) NOT NULL, -- e.g., '01:23:45' (HH:MM:SS)
    FinishPosition INT NOT NULL,
    CONSTRAINT FK_Result_Enrolment FOREIGN KEY (EnrolmentId) REFERENCES [Enrolment](EnrolmentId) ON DELETE CASCADE
);
GO


-- Create Indexes for Performance

CREATE INDEX IX_Event_OrganiserId ON [Event](OrganiserId);
CREATE INDEX IX_Event_Date ON [Event]([Date]);
CREATE INDEX IX_Category_EventId ON [Category](EventId);
CREATE INDEX IX_Enrolment_ParticipantId ON [Enrolment](ParticipantId);
CREATE INDEX IX_Enrolment_EventId ON [Enrolment](EventId);
CREATE INDEX IX_Enrolment_CategoryId ON [Enrolment](CategoryId);
CREATE INDEX IX_Result_EnrolmentId ON [Result](EnrolmentId);
CREATE INDEX IX_User_Email ON [User](Email);
GO


-- Insert Seed Data



-- 1. Insert Users (2 Organisers, 2 Participants)
-- Note: Passwords are hashed using BCrypt
-- Password for all: 'Password123!'
-- Hashed using BCrypt with salt rounds 10

INSERT INTO [User] (Email, PasswordHash, FirstName, LastName, [Role], ProfilePictureUrl, CreatedAt)
VALUES 
    ('john.organiser@raceday.co.za', '$2a$10$SOMERANDOMHASH1JOHN1234567890', 'John', 'Dlamini', 'Organiser', NULL, GETDATE()),
    ('sarah.organiser@raceday.co.za', '$2a$10$SOMERANDOMHASH2SARAH1234567890', 'Sarah', 'Petersen', 'Organiser', NULL, GETDATE()),
    ('thabo.participant@raceday.co.za', '$2a$10$SOMERANDOMHASH3THABO1234567890', 'Thabo', 'Mbeki', 'Participant', NULL, GETDATE()),
    ('linda.participant@raceday.co.za', '$2a$10$SOMERANDOMHASH4LINDA1234567890', 'Linda', 'Naidoo', 'Participant', NULL, GETDATE());
GO


-- 2. Insert Events (3 events)

INSERT INTO [Event] (OrganiserId, [Name], [Description], [Date], [Location], Distance, EventType, BannerImageUrl, CreatedAt, UpdatedAt)
VALUES 
    (1, 'Soweto Marathon', 'Annual Soweto Marathon through the streets of Soweto, one of South Africa''s most iconic races.', '2026-11-05 06:00:00', 'Soweto, Johannesburg', '42km', 'Run', NULL, GETDATE(), NULL),
    (1, 'Cape Town Cycle Tour', 'The world''s largest timed cycle race around the Cape Peninsula.', '2026-03-08 08:00:00', 'Cape Town', '109km', 'Cycle', NULL, GETDATE(), NULL),
    (2, 'Durban Park Run', 'Weekly community park run event at the Durban Botanic Gardens.', '2026-09-12 07:30:00', 'Durban Botanical Gardens', '5km', 'Walk', NULL, GETDATE(), NULL);
GO


-- 3. Insert Categories for Events

-- Categories for Soweto Marathon (EventId = 1)
INSERT INTO [Category] (EventId, [Name], [Description])
VALUES 
    (1, 'Under 20', 'Participants aged 19 and under'),
    (1, 'Senior', 'Participants aged 20-39'),
    (1, 'Veteran', 'Participants aged 40 and above');

-- Categories for Cape Town Cycle Tour (EventId = 2)
INSERT INTO [Category] (EventId, [Name], [Description])
VALUES 
    (2, '10km', 'Short distance category for beginners'),
    (2, '21km', 'Half marathon distance'),
    (2, '42km', 'Full marathon distance');

-- Categories for Durban Park Run (EventId = 3)
INSERT INTO [Category] (EventId, [Name], [Description])
VALUES 
    (3, 'Junior', 'Under 12 years old'),
    (3, 'Open', 'Ages 12 and above');
GO


-- 4. Insert Sample Enrolments

INSERT INTO [Enrolment] (ParticipantId, EventId, CategoryId, [Status], EnrolmentDate)
VALUES 
    -- Thabo (ParticipantId = 3) enrolments
    (3, 1, 2, 'Confirmed', '2026-10-15 10:30:00'),  -- Thabo enrols in Soweto Marathon - Senior category
    (3, 2, 5, 'Pending', '2026-02-20 14:00:00'),     -- Thabo enrols in Cape Town Cycle Tour - 21km
    
    -- Linda (ParticipantId = 4) enrolments
    (4, 1, 3, 'Confirmed', '2026-10-20 09:15:00'),   -- Linda enrols in Soweto Marathon - Veteran category
    (4, 3, 5, 'Confirmed', '2026-09-01 08:00:00');   -- Linda enrols in Durban Park Run - Open category
GO


-- 5. Insert Sample Results

-- Results for completed events (assuming Soweto Marathon is completed)
-- Based on enrolments above
INSERT INTO [Result] (EnrolmentId, FinishTime, FinishPosition)
VALUES 
    -- Thabo's result for Soweto Marathon (EnrolmentId = 1)
    (1, '03:45:22', 15),   -- 15th place out of 312 finishers
    
    -- Linda's result for Soweto Marathon (EnrolmentId = 3)
    (3, '04:12:47', 42),   -- 42nd place
    
    -- Linda's result for Durban Park Run (EnrolmentId = 4)
    (4, '00:28:15', 7);    -- 7th place
GO



GO


-- END OF SCRIPT
